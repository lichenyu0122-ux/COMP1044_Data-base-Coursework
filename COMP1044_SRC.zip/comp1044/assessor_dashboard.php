<?php
// assessor_dashboard.php
require_once 'config.php';
checkRole(['assessor']);

$assessor_id = $_SESSION['user_id'];

// Handle score submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_scores'])) {
    $student_id = intval($_POST['student_id']);
    $criteria_ids = $_POST['criteria_id'];
    $scores = $_POST['score'];
    $comments = $_POST['comments'];
    
    foreach ($criteria_ids as $index => $criteria_id) {
        $score = floatval($scores[$index]);
        $comment = mysqli_real_escape_string($conn, $comments[$index]);
        
        $check_query = "SELECT * FROM assessment_results WHERE student_id = ? AND criteria_id = ?";
        $check_stmt = mysqli_prepare($conn, $check_query);
        mysqli_stmt_bind_param($check_stmt, "ii", $student_id, $criteria_id);
        mysqli_stmt_execute($check_stmt);
        $check_result = mysqli_stmt_get_result($check_stmt);
        
        if (mysqli_num_rows($check_result) > 0) {
            $query = "UPDATE assessment_results SET score = ?, comments = ?, assessed_by = ?, assessment_date = NOW() 
                      WHERE student_id = ? AND criteria_id = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "dsiii", $score, $comment, $assessor_id, $student_id, $criteria_id);
        } else {
            $query = "INSERT INTO assessment_results (student_id, criteria_id, score, comments, assessed_by) 
                      VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "iidsi", $student_id, $criteria_id, $score, $comment, $assessor_id);
        }
        mysqli_stmt_execute($stmt);
    }
    $success = "Scores saved successfully!";
}

// Get students assigned to this assessor
$students_query = "SELECT s.* FROM students s WHERE s.assessor_id = ?";
$stmt = mysqli_prepare($conn, $students_query);
mysqli_stmt_bind_param($stmt, "i", $assessor_id);
mysqli_stmt_execute($stmt);
$students_result = mysqli_stmt_get_result($stmt);

// Get assessment criteria
$criteria_query = "SELECT * FROM assessment_criteria ORDER BY criteria_id";
$criteria_result = mysqli_query($conn, $criteria_query);
$criteria = [];
while ($row = mysqli_fetch_assoc($criteria_result)) {
    $criteria[] = $row;
}

// Get selected student's existing scores
$selected_student = isset($_GET['student']) ? intval($_GET['student']) : 0;
$existing_scores = [];
if ($selected_student) {
    $score_query = "SELECT criteria_id, score, comments FROM assessment_results WHERE student_id = ?";
    $score_stmt = mysqli_prepare($conn, $score_query);
    mysqli_stmt_bind_param($score_stmt, "i", $selected_student);
    mysqli_stmt_execute($score_stmt);
    $score_result = mysqli_stmt_get_result($score_stmt);
    while ($row = mysqli_fetch_assoc($score_result)) {
        $existing_scores[$row['criteria_id']] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assessor Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .navbar { background: #2c3e50; color: white; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
        .navbar h1 { font-size: 20px; }
        .logout-btn { background: #e74c3c; color: white; padding: 8px 15px; text-decoration: none; border-radius: 5px; }
        .container { max-width: 1200px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 30px; overflow: hidden; }
        .card-header { background: #3498db; color: white; padding: 15px 20px; font-size: 18px; font-weight: 600; }
        .card-body { padding: 20px; }
        .student-select select { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; }
        table { width: 100%; border-collapse: collapse; }
        table th, table td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        table th { background: #f8f9fa; font-weight: 600; }
        input[type="number"] { width: 80px; padding: 8px; border: 1px solid #ddd; border-radius: 5px; }
        textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 5px; resize: vertical; }
        button { background: #27ae60; color: white; padding: 12px 30px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; margin-top: 20px; }
        .alert-success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
        .total-score { background: #e8f4fd; padding: 15px; border-radius: 5px; margin-top: 20px; text-align: center; }
        .total-score .score { font-size: 36px; font-weight: bold; color: #27ae60; }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Internship Result Management System - Assessor Dashboard</h1>
        <a href=" " class="logout-btn">Logout</a >
    </div>
    
    <div class="container">
        <?php if (isset($success)): ?>
            <div class="alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header">Select Student for Assessment</div>
            <div class="card-body">
                <div class="student-select">
                    <select id="studentSelect" onchange="location.href='?student=' + this.value">
                        <option value="">-- Select a student --</option>
                        <?php while ($student = mysqli_fetch_assoc($students_result)): ?>
                            <option value="<?php echo $student['student_id']; ?>" 
                                <?php echo ($selected_student == $student['student_id']) ? 'selected' : ''; ?>>
                                <?php echo $student['student_code'] . ' - ' . $student['student_name'] . ' (' . $student['programme'] . ')'; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
        </div>
        
        <?php if ($selected_student): 
            $student_query = "SELECT * FROM students WHERE student_id = ?";
            $stmt = mysqli_prepare($conn, $student_query);
            mysqli_stmt_bind_param($stmt, "i", $selected_student);
            mysqli_stmt_execute($stmt);
            $student = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        ?>
            <div class="card">
                <div class="card-header">Assessment Form: <?php echo $student['student_name']; ?> (<?php echo $student['student_code']; ?>)</div>
                <div class="card-body">
                    <form method="POST" action="" onsubmit="return validateScores()">
                        <input type="hidden" name="student_id" value="<?php echo $selected_student; ?>">
                        <table>
                            <thead>
                                <tr><th>Assessment Criteria</th><th>Weightage</th><th>Score (0-100)</th><th>Comments</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($criteria as $c): 
                                    $score = $existing_scores[$c['criteria_id']]['score'] ?? '';
                                    $comment = $existing_scores[$c['criteria_id']]['comments'] ?? '';
                                ?>
                                <tr>
                                    <td><?php echo $c['criteria_name']; ?></td>
                                    <td><?php echo $c['weightage']; ?>%</td>
                                    <td>
                                        <input type="hidden" name="criteria_id[]" value="<?php echo $c['criteria_id']; ?>">
                                        <input type="number" name="score[]" value="<?php echo $score; ?>" 
                                               min="0" max="100" step="0.01" class="score-input" onchange="calculateTotal()">
                                    </td>
                                    <td><textarea name="comments[]" rows="2"><?php echo htmlspecialchars($comment); ?></textarea></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <div class="total-score"><h3>Total Internship Score</h3><div class="score" id="totalScore">0.00</div></div>
                        <button type="submit" name="save_scores">Save Assessment</button>
                    </form>
                </div>
            </div>
            
            <script>
                const weightages = <?php 
                    $weights = [];
                    foreach ($criteria as $c) { $weights[$c['criteria_id']] = $c['weightage']; }
                    echo json_encode($weights);
                ?>;
                function calculateTotal() {
                    let total = 0;
                    let inputs = document.querySelectorAll('.score-input');
                    let weightList = Object.values(weightages);
                    inputs.forEach((input, index) => {
                        let score = parseFloat(input.value) || 0;
                        total += (score * weightList[index] / 100);
                    });
                    document.getElementById('totalScore').innerText = total.toFixed(2);
                }
                function validateScores() {
                    let inputs = document.querySelectorAll('.score-input');
                    for (let input of inputs) {
                        let score = parseFloat(input.value);
                        if (isNaN(score) || score < 0 || score > 100) {
                            alert('Please enter scores between 0 and 100');
                            return false;
                        }
                    }
                    return true;
                }
                calculateTotal();
            </script>
        <?php endif; ?>
    </div>
</body>
</html>