<?php
require_once 'config.php';
session_start();

$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($student_id == 0) {
    header('Location: admin_dashboard.php');
    exit();
}

$back_url = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') ? 'admin_dashboard.php' : 'assessor_dashboard.php';

$student_query = "SELECT * FROM students WHERE student_id = ?";
$stmt = mysqli_prepare($conn, $student_query);
mysqli_stmt_bind_param($stmt, "i", $student_id);
mysqli_stmt_execute($stmt);
$student = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

$results_query = "SELECT ac.criteria_name, ac.weightage, ar.score, ar.comments, u.full_name as assessor_name
                  FROM assessment_criteria ac
                  LEFT JOIN assessment_results ar ON ac.criteria_id = ar.criteria_id AND ar.student_id = ?
                  LEFT JOIN users u ON ar.assessed_by = u.user_id
                  ORDER BY ac.criteria_id";
$stmt = mysqli_prepare($conn, $results_query);
mysqli_stmt_bind_param($stmt, "i", $student_id);
mysqli_stmt_execute($stmt);
$results = mysqli_stmt_get_result($stmt);

$total_score = 0;
if (function_exists('calculateTotalScore')) {
    $total_score = calculateTotalScore($student_id, $conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Details</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; color: #333; }
        .navbar { background: #2c3e50; color: white; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
        .navbar h1 { font-size: 20px; }
        .back-btn { background: #3498db; color: white; padding: 8px 15px; text-decoration: none; border-radius: 5px; transition: 0.3s; }
        .back-btn:hover { background: #2980b9; }
        .container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 30px; overflow: hidden; }
        .card-header { background: #3498db; color: white; padding: 15px 20px; font-size: 18px; font-weight: 600; }
        .card-body { padding: 25px; }
        .student-info { background: #e8f4fd; padding: 20px; border-radius: 8px; margin-bottom: 25px; border-left: 5px solid #3498db; }
        .student-info p { margin: 8px 0; }
        table { width: 100%; border-collapse: collapse; }
        table th, table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #eee; }
        table th { background: #f8f9fa; font-weight: 600; color: #666; }
        .total-score-box { background: #d4edda; padding: 20px; border-radius: 8px; text-align: center; margin-top: 30px; border: 1px solid #c3e6cb; }
        .score-value { font-size: 32px; font-weight: bold; color: #27ae60; }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Student Details</h1>
        <a href="<?php echo $back_url; ?>" class="back-btn">Back to Dashboard</a>
    </div>
    
    <div class="container">
        <div class="card">
            <div class="card-header">Student Information</div>
            <div class="card-body">
                <div class="student-info">
                    <p><strong>Student ID:</strong> <?php echo htmlspecialchars($student['student_code']); ?></p>
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($student['student_name']); ?></p>
                    <p><strong>Programme:</strong> <?php echo htmlspecialchars($student['programme']); ?></p>
                    <p><strong>Company:</strong> <?php echo htmlspecialchars($student['company_name'] ?? 'Not specified'); ?></p>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th>Assessment Criteria</th>
                            <th>Weightage</th>
                            <th>Score</th>
                            <th>Comments</th>
                            <th>Assessed By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($results)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['criteria_name']); ?></td>
                            <td><?php echo $row['weightage']; ?>%</td>
                            <td><?php echo $row['score'] !== null ? number_format($row['score'], 1) : 'Not assessed'; ?></td>
                            <td><?php echo htmlspecialchars($row['comments'] ?: '-'); ?></td>
                            <td><?php echo htmlspecialchars($row['assessor_name'] ?: '-'); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                
                <div class="total-score-box">
                    <h3>Total Internship Score</h3>
                    <div class="score-value"><?php echo number_format($total_score, 2); ?> / 100</div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>